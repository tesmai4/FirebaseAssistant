package com.example.firebaseassistant;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;



import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class MainActivity extends AppCompatActivity {

    EditText fn, sn;
    Button submit;

    DatabaseReference dbref123;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fn =findViewById(R.id.f_et);
        sn =findViewById(R.id.s_et);

        submit =findViewById(R.id.button3);

        dbref123 = FirebaseDatabase.getInstance().getReference("_user_");

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(fn.getText().length() > 0 && sn.getText().length() >0)
                {
                    User user =new User(fn.getText().toString(), sn.getText().toString());
                    dbref123.child(dbref123.push().getKey()).setValue(user);
                }

            }
        });
    }
}